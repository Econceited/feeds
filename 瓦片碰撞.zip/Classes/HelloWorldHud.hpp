//
//  HelloWorldHud.hpp
//  TiledMap
//
//  Created by student on 16/6/17.
//
//

//Heads up display 最上面显示的层（如：皮鞋的头层牛皮）

#ifndef HelloWorldHud_hpp
#define HelloWorldHud_hpp

#include <iostream>
#include "cocos2d.h"
using namespace cocos2d;

#define MENUON_RESOURCE "projectile-button-on.png"
#define MENUOFF_RESOURCE "projectile-button-off.png"

class HelloWorld; //前向声明（或超前声明）

class HelloWorldHud:public Layer
{
public:
    CREATE_FUNC(HelloWorldHud);
    virtual bool init();
  
public:
    CC_SYNTHESIZE(HelloWorld *, _gameLayer, GameLayer);
    
public:
    void labelForNumChanged(int num);
    void changeMode(Ref* sender);
    
public:
    Label *label; //用来显示吃掉的物品的数量
};

#endif /* HelloWorldHud_hpp */
