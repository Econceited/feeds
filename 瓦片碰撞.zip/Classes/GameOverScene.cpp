//
//  GameOverScene.cpp
//  TiledMap
//
//  Created by student on 16/6/17.
//
//

#include "GameOverScene.hpp"
#include "HelloWorldScene.h"

#pragma mark - 创建场景方法
Scene * GameOverScene::createScene()
{
    auto scene = Scene::create();
    auto layer = GameOverScene::create();
    scene->addChild(layer);
    return scene;
}

#pragma mark - 初始化场景方法
bool GameOverScene::init()
{
    if (!Layer::init())
    {
        return false;
    }
    auto winSize = Director::getInstance()->getWinSize();
    
    //添加layer层
    auto layer = LayerColor::create(Color4B(255, 0, 0, 100), winSize.width, winSize.height);
    addChild(layer);
    
    //添加label标签
    auto label = Label::createWithSystemFont("Game Over", "fonts/Marker Felt.ttf", 100);
    label->setPosition(Vec2(winSize.width * 0.5, winSize.height * 0.6));
    label->setColor(Color3B::RED);
    layer->addChild(label);
    
    //添加menu菜单按钮
    auto item1 = MenuItemFont::create("Restart", CC_CALLBACK_1(GameOverScene::item1_CallBack, this));
    item1->setFontSize(40);
    item1->setColor(Color3B::YELLOW);
    
    auto item2 = MenuItemFont::create("Exit", CC_CALLBACK_1(GameOverScene::item2_CallBack, this));
    item2->setFontSize(40);
    item2->setColor(Color3B::YELLOW);
    
    auto menu = Menu::create(item1, item2, NULL);
    menu->setPosition(Vec2(winSize.width * 0.5, winSize.height * 0.4));
    menu->alignItemsHorizontally();//设置菜单横向排列
    menu->alignItemsHorizontallyWithPadding(100); //间距100
    layer->addChild(menu);

    return true;
}

#pragma mark - item1回调方法
void GameOverScene::item1_CallBack(Ref* sender)
{
    Director::getInstance()->replaceScene(HelloWorld::createScene());
}

#pragma mark - item2回调方法
void GameOverScene::item2_CallBack(Ref* sender)
{
    exit(0);
}