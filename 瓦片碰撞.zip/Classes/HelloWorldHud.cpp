//
//  HelloWorldHud.cpp
//  TiledMap
//
//  Created by student on 16/6/17.
//
//

#include "HelloWorldHud.hpp"
#include "HelloWorldScene.h" //使用前向声明后，必须要在.cpp中间中包含头文件，否则编译不通过
USING_NS_CC;

#pragma mark - 初始化场景方法
bool HelloWorldHud::init()
{
    if (!Layer::init())
    {
        return false;
    }
    
    auto winSize = Director::getInstance()->getWinSize();
    
    auto label1 = Label::createWithTTF("个数", "fonts/Marker Felt.ttf", 40);
    label1->setPosition(Vec2(winSize.width * 0.85, winSize.height * 0.9));
    addChild(label1);
    
    label = Label::createWithTTF("0", "fonts/Marker Felt.ttf", 40);
    label->setPosition(Vec2(winSize.width * 0.9, winSize.height * 0.9));
    label->setColor(Color3B::MAGENTA); //品红，洋红色
    addChild(label);
    
    auto on = MenuItemImage::create(MENUON_RESOURCE, MENUON_RESOURCE);
    auto off = MenuItemImage::create(MENUOFF_RESOURCE, MENUOFF_RESOURCE);
    
    auto toggle = MenuItemToggle::createWithCallback(CC_CALLBACK_1(HelloWorldHud::changeMode, this), on, off, NULL);
    auto menu = Menu::create(toggle, NULL);
    menu->setPosition(Vec2(50, 50));
    addChild(menu);

    return true;
}

#pragma mark - 更新label的显示数字
void HelloWorldHud::labelForNumChanged(int num)
{
    char str[10];
    sprintf(str, "%d", num);
    
    label->setString(str);
}

#pragma mark - 英雄模式的更改
void HelloWorldHud::changeMode(Ref* sender)
{
    if (_gameLayer->getMode() == 0)
    {
        _gameLayer->setMode(1);
    }
    else
    {
        _gameLayer->setMode(0);
    }
}