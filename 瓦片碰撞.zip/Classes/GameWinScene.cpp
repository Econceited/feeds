//
//  GameWinScene.cpp
//  TiledMap
//
//  Created by student on 16/6/17.
//
//

#include "GameWinScene.hpp"
#include "HelloWorldScene.h"

#pragma mark - 创建场景方法
Scene * GameWinScene::createScene()
{
    auto scene = Scene::create();
    auto layer = GameWinScene::create();
    scene->addChild(layer);
    return scene;
}

#pragma mark - 初始化场景方法
bool GameWinScene::init()
{
    if (!Layer::init())
    {
        return false;
    }
    auto winSize = Director::getInstance()->getWinSize();
    
    //添加label标签
    auto label = Label::createWithSystemFont("Game Win", "fonts/Marker Felt.ttf", 100);
    label->setPosition(Vec2(winSize.width * 0.5, winSize.height * 0.6));
    label->setColor(Color3B::RED);
    addChild(label);
    
    //添加menu菜单按钮
    auto item1 = MenuItemFont::create("Restart", CC_CALLBACK_1(GameWinScene::item1_CallBack, this));
    item1->setFontSize(40);
    item1->setColor(Color3B::YELLOW);
    
    auto item2 = MenuItemFont::create("Exit", CC_CALLBACK_1(GameWinScene::item2_CallBack, this));
    item2->setFontSize(40);
    item2->setColor(Color3B::YELLOW);
    
    auto menu = Menu::create(item1, item2, NULL);
    menu->setPosition(Vec2(winSize.width * 0.5, winSize.height * 0.4));
    menu->alignItemsHorizontally();//横向排列
    menu->alignItemsHorizontallyWithPadding(100); //间距100
    addChild(menu);
    
    //添加粒子特效
    auto mSystem = ParticleSystemQuad::create("fengye.plist");
    mSystem->setTextureWithRect(Director::getInstance()->getTextureCache()->addImage("fengye.png"),Rect(0,0,91,91));
    mSystem->setBlendAdditive(true);
    mSystem->setPosition(Vec2(winSize.width/2.0, winSize.height/2.0));
    addChild(mSystem);
    
    return true;
}

#pragma mark - item1回调方法
void GameWinScene::item1_CallBack(Ref* sender)
{
    Director::getInstance()->replaceScene(HelloWorld::createScene());
}

#pragma mark - item2回调方法
void GameWinScene::item2_CallBack(Ref* sender)
{
    exit(0);
}