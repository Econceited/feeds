#include "HelloWorldScene.h"
#include "GameOverScene.hpp"
#include "GameWinScene.hpp"


USING_NS_CC;

HelloWorldHud* HelloWorld::_hud = NULL; //初始化_hud

#pragma mark - 创建场景方法
Scene* HelloWorld::createScene()
{
    auto scene = Scene::create();
    auto layer = HelloWorld::create();
    scene->addChild(layer);
    
    auto hud = HelloWorldHud::create();
    _hud = hud;
    
    _hud->setGameLayer(layer);
    
    scene->addChild(hud);
    return scene;
}

#pragma mark - 初始化场景方法
bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    
    score = 0;
    _mode = 0; //英雄模式的标志，0代表行走模式，！0代表攻击模式
    
    
    //预加载音乐和音效
    SimpleAudioEngine *audio = SimpleAudioEngine::getInstance();
    audio->preloadBackgroundMusic("TileMap.mp3");
    audio->preloadEffect("hit.mp3");
    audio->preloadEffect("move.mp3");
    audio->preloadEffect("pickup.mp3");
    //播放背景音乐
    audio->playBackgroundMusic("TileMap.mp3");

    
    //加载地图资源
    _tiledmap = TMXTiledMap::create(TILED_RESOURCE);
    addChild(_tiledmap, -1);
    
    //获取背景层
    _background = _tiledmap->getLayer(BACKGROUND_NAME);
    
    //获取标记层
    _meta = _tiledmap->getLayer(META_NAME);
    _meta->setVisible(false);
    
    //获取可收集层
    _foreground = _tiledmap->getLayer(FOREGROUND_NAME);
    
    //获取对象层
    TMXObjectGroup *objects = _tiledmap->getObjectGroup(OBJECTS_NAME);
    CCASSERT(NULL != objects, "Objects group not found"); //抛异常
    
    //获取对象层中的Player对象
    auto player = objects->getObject(PLAYER_NAME);
    CCASSERT(!player.empty(), "Player object not found"); //抛异常
    float x = player.at("x").asFloat(); //等价于：float x = player["x"].asFloat();
    float y = player.at("y").asFloat();
    
    //添加英雄
    _player = Sprite::create(PLAYER_RESOURCE);
    _player->setPosition(x, y);
    _player->setAnchorPoint(Vec2(0, 1));
    addChild(_player);
    
    
    //添加敌人 遍历objects
    for(Value & object:objects->getObjects())
    {
        ValueMap &dic = object.asValueMap();
        if (1 == dic["Enemy"].asInt())
        {
            float x = dic["x"].asFloat();
            float y = dic["y"].asFloat();
            this->addEnemy(Point(x, y));
        }
    }
    
    //调用函数
    setViewPointCenter(_player->getPosition());
    
    //设置单点触摸监听
    auto listener = EventListenerTouchOneByOne::create();
    listener->onTouchBegan = [](Touch *touch, Event *event)
    {
        return true;
    };
    listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
    Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this); //默认注册 0
    
    this->schedule(CC_CALLBACK_1(HelloWorld::testCollision, this), "Collision"); //时间调度器，每一帧调用一次
    
    return true;
}

#pragma mark - 根据英雄的位置调整地图，使英雄一直显示在屏幕中
void HelloWorld::setViewPointCenter(Point p)
{
   /** 把英雄想象成一个相机，地图是移动的
     * 调整地图，使屏幕不要有黑边
     * 尽可能让英雄显示在屏幕的中心位置
     * 将x,y的值计算出来，与屏幕的中心点位置对齐
     * _tiledmap->getMapSize().width：代表格子数
     * _tiledmap->getTileSize().width：代表每个格子的宽度
    **/
    
    auto winSize = Director::getInstance()->getWinSize();
    //当英雄位置小于winSize/2时，以屏幕中心为返回点（避免产生黑边）
    float x = MAX(p.x, winSize.width/2.0); //等价于：float x = p.x>winSize.width/2?p.x:winSize.width/2;
    float y = MAX(p.y, winSize.height/2.0);
    
    //当英雄位置大于winSize/2时，保证英雄在屏幕中心
    x = MIN(x, (_tiledmap->getMapSize().width * _tiledmap->getTileSize().width) - winSize.width/2.0);
    y = MIN(y, (_tiledmap->getMapSize().height * _tiledmap->getTileSize().height) - winSize.height/2.0);
    
    //英雄向右上方移动，layer向左下方移动
    auto centerOfview = Point(winSize.width/2.0, winSize.height/2.0);
    auto viewPoint = centerOfview - Point(x, y);
    this->setPosition(viewPoint);
}

#pragma mark - 单点触摸回调函数：实现英雄的移动动作
void HelloWorld::onTouchEnded(Touch *touch, Event *event)
{
    auto touchLocation = touch->getLocation(); //获取点击位置
    touchLocation = this->convertToNodeSpace(touchLocation); //世界坐标系转节点坐标系
    
    if (_mode == 0) //行走模式
    {
        auto playerPosition = _player->getPosition(); //获取英雄位置
        auto dis = touchLocation - playerPosition; //点击位置与英雄之间的距离
        
        if (abs(dis.x) > abs(dis.y)) //X方向上移动
        {
            if (dis.x > 0) //向右
            {
                playerPosition.x += _tiledmap->getTileSize().width;
            }
            else //向左
            {
                playerPosition.x -= _tiledmap->getTileSize().width;
            }
        }
        else //Y方向上移动
        {
            if (dis.y > 0) //向上
            {
                playerPosition.y += _tiledmap->getTileSize().height;
            }
            else //向下
            {
                playerPosition.y -= _tiledmap->getTileSize().height;
            }
        }
        
        //判断英雄是否在屏幕可见范围内移动
        if (playerPosition.x > 0 && playerPosition.y > 0 && playerPosition.x < (_tiledmap->getMapSize().width * _tiledmap->getTileSize().width) && playerPosition.y <(_tiledmap->getMapSize().height * _tiledmap->getTileSize().height))
        {
            //更新英雄位置
            this->setPlayerPosition(playerPosition);
        }
        
        this->setViewPointCenter(playerPosition); //更新视点
    }
    else //攻击模式
    {
        //Create a bullet and position is player's position
        auto bullet = Sprite::create(BULLET_RECOURCE);
        bullet->setPosition(_player->getPosition());
        bullet->setAnchorPoint(Vec2(0, 1));
        addChild(bullet);
        _bullets.pushBack(bullet); //将子弹存储到_bullets容器中
        
        auto dis = touchLocation - bullet->getPosition(); //子弹发射点距点击点的距离
        auto radian = dis.y / dis.x; //子弹发射位置到点击位置之间连线的角度
        
        int realX ; //X方向上的最远距离
        if (dis.x > 0) //子弹向右
        {
            realX = _tiledmap->getMapSize().width * _tiledmap->getTileSize().width + bullet->getContentSize().width/2.0; //向右最远距离
        }
        else //子弹向左
        {
            realX = -(_tiledmap->getMapSize().width * _tiledmap->getTileSize().width + bullet->getContentSize().width/2.0); //向左最远距离
        }
        
        int realY = ((realX - bullet->getPosition().x) * radian) + bullet->getPosition().y;//Y方向上的最远距离
        
        auto realDes = Point(realX, realY); //子弹到达的最远点的位置
        
        float offDes = sqrt(pow(realX - bullet->getPosition().x, 2) + pow(realY - bullet->getPosition().y, 2)); //子弹运动的最远距离（勾股定理）
        
        auto moveTo = MoveTo::create(offDes/480.0, realDes);
        auto moveDone = CallFuncN::create(CC_CALLBACK_1(HelloWorld::releaseBullet, this));
        bullet->runAction(Sequence::create(moveTo, moveDone, NULL));
    }
}

#pragma mark - 设置英雄的位置以及通过障碍物的逻辑判断
void HelloWorld::setPlayerPosition(Point p)
{
    //得到英雄的瓦片坐标
    auto tiledCoord = this->getPlayerTiledCoord(p);
    //获取在Meta层中，英雄瓦片位置的唯一标识GID
    auto GID = _meta->getTileGIDAt(tiledCoord);
    if (GID)
    {
        //当我们使用GID来查找指定tile的属性的时候。它返回一个属性字典
        //获取图块的属性
        auto properties = _tiledmap->getPropertiesForGID(GID).asValueMap();
        if (!properties.empty())
        {
            //判断障碍物是否能通过
            if (properties["Collidable"].asString() == "True")
            {
                SimpleAudioEngine::getInstance()->playEffect("hit.mp3");
                return;
            }
            //如果障碍物为可吃的，则移除该障碍物
            if (properties["Collectable"].asString() == "True")
            {
                if (_foreground->getTileGIDAt(tiledCoord))
                {
                    SimpleAudioEngine::getInstance()->playEffect("pickup.mp3");
                    _foreground->removeTileAt(tiledCoord); //将标记层的格子移除
                    score++; //加分
                    _hud->labelForNumChanged(score); //实现分数的动态变化
                   //判断当获取8个目标后游戏挑战成功
                    if (score == 8)
                    {
                        Director::getInstance()->replaceScene(GameWinScene::createScene());
                    }
                }
                else
                {
                    SimpleAudioEngine::getInstance()->playEffect("move.mp3");
                }
            }
        }
    }
    _player->setPosition(Vec2(p.x, p.y));
    SimpleAudioEngine::getInstance()->playEffect("move.mp3");
    
    
}

#pragma mark - 获取英雄在地图中的位置
Point HelloWorld::getPlayerTiledCoord(Point p)
{
    // 获取英雄在瓦片地图的位置，瓦片地图是以左上角为原点的
    int x = p.x /_tiledmap->getTileSize().width;
    int y = (_tiledmap->getMapSize().width * _tiledmap->getTileSize().width -p.y) / _tiledmap->getTileSize().height;
    
    return Point(x, y);
}

#pragma mark - 添加敌人
void HelloWorld::addEnemy(Point p)
{
    auto enemy = Sprite::create(ENEMY_RESOURCE);
    enemy->setPosition(p);
    addChild(enemy);
    _enemies.pushBack(enemy); //将敌人存储到_enemies容器中
    
    this->animate(enemy); //敌人跟随英雄运动
}

#pragma mark - 设置敌人跟随英雄运动
void HelloWorld::animate(Sprite *enemy)
{
    auto dis = _player->getPosition() - enemy->getPosition();
    
    //设置敌人的脸朝向英雄
    auto radian = atanf(dis.y / dis.x); //反正切:atanf 弧度:radian
    auto degree = CC_RADIANS_TO_DEGREES(radian); //弧度转角度
    /*
     degree = radian * 180 / π   弧度转角度计算方法
     数学中：角度坐标系，逆时针为正 Cocos:坐标系，顺时针为正  都以X轴正方向为0
     */
    auto cocosAngle = -1 * degree;
    
    if (dis.x < 0)
    {
        cocosAngle += 180;
    }
    enemy->setRotation(cocosAngle);
    
    //0.5秒移动10个像素
    float duration = 0.5f;
    dis.normalize(); //单位向量
    dis.x *= 10;
    dis.y *= 10;
    
    auto moveBy = MoveBy::create(duration, dis);
    auto moveDone = CallFuncN::create(CC_CALLBACK_1(HelloWorld::enemyMoveFinished, this));
    enemy->runAction(Sequence::create(moveBy, moveDone, NULL));
}

#pragma mark - 敌人移动完成时回调函数
void HelloWorld::enemyMoveFinished(Ref *sender)
{
    auto enemy = (Sprite *)sender;
    this->animate(enemy);
}

#pragma mark - 移除子弹
void HelloWorld::releaseBullet(Ref *sender)
{
    auto bullet = (Sprite *)sender;
    /** eraseObject 函数注释
     *  @brief Remove a certain object in Vector.
     *  @param object The object to be removed.
     *  @param removeAll Whether to remove all elements with the same value.
     *  If its value is 'false', it will just erase the first occurrence.
     */
    _bullets.eraseObject(bullet);
    this->removeChild(bullet);
    
}

#pragma mark - 碰撞检测
void HelloWorld::testCollision(float dt)
{
    for (auto enemy: _enemies) //遍历 _enemies容器
    {
        auto enemyRect = enemy->getBoundingBox();
        if (enemyRect.containsPoint(_player->getPosition()))
        {
            //失败 弹出失败场景
            log("游戏失败啦");
            Director::getInstance()->replaceScene(GameOverScene::createScene());
            this->unschedule(schedule_selector(HelloWorld::testCollision)); //关闭定时器
        }
    }
    
    Vector<Sprite *> bulletToDelete; //设置子弹的代理容器
    for (auto bullet: _bullets) //遍历 _bullets容器
    {
        auto bullletRect = bullet->getBoundingBox();
        
        Vector<Sprite *> enemyToDelete; //设置敌人的代理容器
        for (auto enemy: _enemies)
        {
            auto enemyRect = enemy->getBoundingBox();
            if (bullletRect.intersectsRect(enemyRect))
            {
                log("子弹打中了敌人");
                enemyToDelete.pushBack(enemy);
            }
        }
        
        if (enemyToDelete.size() > 0)
        {
            bulletToDelete.pushBack(bullet);
        }
        
        //移除被子弹打中的敌人
        for (auto delete_enemy: enemyToDelete)
        {
            _enemies.eraseObject(delete_enemy);
            this->removeChild(delete_enemy);
        }
        enemyToDelete.clear(); //清空代理容器
    }
    
    //移除打中敌人的子弹
    for (auto delete_bullet: bulletToDelete)
    {
        _bullets.eraseObject(delete_bullet);
        this->removeChild(delete_bullet);
    }
    bulletToDelete.clear(); //清空代理容器
    
}