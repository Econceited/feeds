//
//  GameOverScene.hpp
//  TiledMap
//
//  Created by student on 16/6/17.
//
//

#ifndef GameOverScene_hpp
#define GameOverScene_hpp

#include <iostream>
#include "cocos2d.h"
using namespace cocos2d;

class GameOverScene:public Layer
{
public:
    CREATE_FUNC(GameOverScene);
    virtual bool init();
    static Scene *createScene();
    
public:
    void item1_CallBack(Ref* sender);
    void item2_CallBack(Ref* sender);
};

#endif /* GameOverScene_hpp */
