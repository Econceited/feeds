#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "HelloWorldHud.hpp"
using namespace cocos2d;
using namespace std;

#include "SimpleAudioEngine.h" //播放音乐头文件及命名空间
using namespace CocosDenshion;

//宏定义，方便修改
#define TILED_RESOURCE "TiledMap.tmx"
//#define TILED_RESOURCE "MyTiled.tmx"
#define BACKGROUND_NAME "Background"
#define OBJECTS_NAME "Object"
#define PLAYER_NAME "Player"
#define META_NAME "Meta"
#define FOREGROUND_NAME "Foreground"
#define PLAYER_RESOURCE "Player.png"
#define ENEMY_RESOURCE "enemy1.png"
#define BULLET_RECOURCE "Projectile.png"


class HelloWorld : public Layer
{
public:
    static Scene* createScene();
    virtual bool init()override;
    CREATE_FUNC(HelloWorld);
    
public:
    //设置单点触摸监听
    void onTouchEnded(Touch *touch, Event *event)override;
    
public:
    //英雄第一视角，取得视图中心点位置，保证英雄一直显示在屏幕上
    void setViewPointCenter(Point p);
    
    //更新英雄位置，设置英雄的位置以及通过障碍物的逻辑判断
    void setPlayerPosition(Point p);
    
    //将英雄的坐标转化为瓦片地图中的坐标
    Point getPlayerTiledCoord(Point p);
    
    //添加敌人
    void addEnemy(Point p);
    
    //敌人跟随英雄运动 0.3秒移动10个像素
    void animate(Sprite *enemy);
    
    //敌人执行完一套动作，在该函数中递归调用animate
    void enemyMoveFinished(Ref *sender);
    
    //移除超出地图区域的子弹
    void releaseBullet(Ref *sender);
    
    //碰撞检测
    void testCollision(float dt);
    
private:
    TMXTiledMap *_tiledmap; //瓦片地图
    
    TMXLayer *_background; //背景层
    TMXLayer *_meta; //标记层
    TMXLayer *_foreground; //前置层
    
    Sprite *_player; //对象英雄
    
    
    int score; //分数
    
    static HelloWorldHud* _hud;
    
    CC_SYNTHESIZE(int, _mode, Mode);
    
    Vector<Sprite *> _enemies; //存储敌人
    Vector<Sprite *> _bullets; //存储子弹
};

#endif // __HELLOWORLD_SCENE_H__
